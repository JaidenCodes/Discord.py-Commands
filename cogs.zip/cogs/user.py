import discord
from discord.ext import commands
from discord.utils import get
import asyncio
import pymongo
from pymongo import MongoClient

class UserCommands(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.command()
    async def hello(self, ctx):
        await ctx.send(f"Hello back to you, <@{ctx.author.id}>!")

    @commands.command()
    async def slap(self, ctx, member: discord.Member):
        await ctx.send(f"<@{ctx.author.id}> slapped {member}!")
        await ctx.send(f"https://tenor.com/view/slap-annoyed-irritated-kid-gif-5013065")

    @commands.command()
    async def report(self, ctx, member: discord.Member, *, reason):
        if member == ctx.author:
            return await ctx.send("You cannot report your own self.")
        channel = self.client.get_channel(898899315404193832)
        await channel.send(f"**{ctx.author}** | **{ctx.author.id}** has **__REPORTED__** user: **{member}** | **{member.id}** for the reason: `{reason}`")
        await ctx.send("✅ Your report has been sent. Thank you.")
        
    @commands.command()
    async def users(self, ctx):
        await ctx.send(f"There are currently **{len(self.client.users)}** users in total.")

    @commands.command(pass_context = True)
    @commands.has_permissions(manage_messages=True)
    async def mute(self, ctx, member: discord.Member, *, reason=None):
        roleToAdd = get(ctx.guild.roles, name="Muted")
        await member.add_roles(roleToAdd)
        await ctx.send(f"✅ <@{member.id}> (**{member.id}**) was **__MUTED__** by <@{ctx.author.id}> for the reason: `{reason}`!")


    @commands.command()
    async def ping(self, ctx):
        await ctx.send(f"👀 Pong.... **{round(self.client.latency*1000)}ms**!")


    @commands.command(pass_context = True)
    @commands.has_permissions(manage_messages=True)
    async def unmute(self, ctx, member: discord.Member):
        roleToAdd = get(ctx.guild.roles, name="Muted")
        await member.remove_roles(roleToAdd)
        await ctx.send(f"✅ <@{member.id}> (**{member.id}**) was **__UNMUTED__** by <@{ctx.author.id}>!")
        await ctx.send(embed=embed)

            
    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def purge(self, ctx, limit: int):
        await ctx.channel.purge(limit=limit)
        msg = await ctx.send(f"✅ Deleted **{limit}** messages.")
        await asyncio.sleep(5)
        await msg.delete()

    #The below code bans player.
    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member : discord.Member, *, reason = None):
        await ctx.send(f"✅ {member} has been banned for the reason `{reason}` by <@{ctx.author.id}>")
        await member.ban(reason = reason)

    #The below code unbans player.
    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def unban(self, ctx, *, member_id: int):
        await ctx.guild.unban(discord.Object(id=member_id))
        await ctx.send(f"✅ Unbanned {member_id}")

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member : discord.Member, *, reason = None):
        await ctx.send(f"✅ {member} has been kicked for the reason `{reason}` by <@{ctx.author.id}>")
        await member.kick()

    @commands.command()
    async def invite(self, ctx):
        embed = discord.Embed(
            color=ctx.author.color, description="Invite BubbleBot")
        embed.add_field(name="Invite me by clicking the link below", value=f"[Invite BubbleBot](https://discord.com/api/oauth2/authorize?client_id=897880399089373186&permissions=8&scope=bot)")
        embed.set_author(name=ctx.author, icon_url=ctx.author.avatar_url)
        embed.set_thumbnail(url=ctx.guild.icon_url)
        await ctx.send(embed=embed)
        
    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def warn(self, ctx, member : discord.Member, *, reason = None):
        await ctx.send(f"✅ {member} has been warned for the reason `{reason}` by <@{ctx.author.id}>")
        await member.send(f"📛 **You have been warned in {ctx.guild.name}** 📛\nStaff: {ctx.author}\nReason: `{reason}`")


    @commands.command()
    @commands.is_owner()
    async def guilds(self, ctx, amt: int = 0):
        embed = discord.Embed(color=self.client.user.color)
        embed.set_author(name=f"Guild list ({amt} to {amt+5})",
                        icon_url=self.client.user.avatar_url)

        for x in self.client.guilds[amt: amt+5]:
            embed.add_field(
                name=f"Guild ID: {x.id}", value=f"**Guild > ** {x.name}\n**Owner >** {x.owner} ({x.owner.id})", inline=False)

        await ctx.send(embed=embed)

def setup(client):
    client.add_cog(UserCommands(client))